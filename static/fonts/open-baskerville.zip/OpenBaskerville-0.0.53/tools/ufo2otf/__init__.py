from compilers import Compiler
from diagnostics import diagnostics, FontError